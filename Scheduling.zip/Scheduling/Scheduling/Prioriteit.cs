﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scheduling
{
    class Prioriteit
    {
        public static List<Resultaat> Run(List<Proses> jobList)
        {
            int currentProcess = 0;
            int cpuTime = 0;
            int cpuDone = 0;
            int runTime = 0;
            int min;
            int SameValue;
            List<Resultaat> ResultaatList = new List<Resultaat>();
            List<Resultaat> readyQueue = new List<Resultaat>();
            do
            {
                if (jobList.Count != 0)
                {
                    if (jobList.ElementAt(0).ArriveTime == runTime) //Runtime 
                    {
                        SameValue = 1;
                        for (int i = 1; i < jobList.Count; i++, SameValue++)    
                        {
                            if (jobList.ElementAt(0).ArriveTime != jobList.ElementAt(i).ArriveTime) 
                                break;
                        }
                        for (int i = 0; i < SameValue; i++) 
                        {
                            readyQueue.Add(new Resultaat(jobList.ElementAt(0).ProcessID, 0, jobList.ElementAt(0).BurstTime, 0, jobList.ElementAt(0).Priority));
                            jobList.RemoveAt(0);
                        }
                    }
                }
                if (currentProcess == 0)
                {
                    if (readyQueue.Count != 0)
                    {
                        min = 0;
                        for (int i = 1; i < readyQueue.Count; i++)
                            if (readyQueue.ElementAt(min).Priority > readyQueue.ElementAt(i).Priority)
                                min = i;
                        ResultaatList.Add(new Resultaat(readyQueue.ElementAt(min).processID, runTime,
                        readyQueue.ElementAt(min).burstTime, readyQueue.ElementAt(min).waitingTime, readyQueue.ElementAt(min).Priority));
                        cpuDone = readyQueue.ElementAt(min).burstTime;
                        cpuTime = 0;
                        currentProcess = readyQueue.ElementAt(min).processID;
                        readyQueue.RemoveAt(min);
                    }
                }
                else
                {
                    if (cpuTime == cpuDone)
                    {
                        currentProcess = 0;
                        continue;
                    }
                }
                cpuTime++;
                runTime++;
                for (int i = 0; i < readyQueue.Count; i++)
                {
                    readyQueue.ElementAt(i).waitingTime++;
                }
            } while (jobList.Count != 0 || readyQueue.Count != 0 || currentProcess != 0);

            return ResultaatList;
        }
    }
}
