﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Scheduling
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        public List<Proses> prcList, prcView;
        public List<Resultaat> resList;

        public Boolean[] skedule = new bool[6];
        public int sliceTime = 5;
        public bool none = true;



       private void processBindingNavigatorSaveItem_Click(object sender, EventArgs e)
         {
             this.Validate();
             this.processBindingSource.EndEdit();
             this.tableAdapterManager.UpdateAll(this.scheduling_algorithms1DataSet2);

         }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'scheduling_algorithms1DataSet2.Process' table. You can move, or remove it, as needed.
            this.processTableAdapter.Fill(this.scheduling_algorithms1DataSet2.Process);


           
            // TODO: This line of code loads data into the 'scheduling_algorithms1DataSet.Process' table. You can move, or remove it, as needed.
            this.processTableAdapter.Fill(this.scheduling_algorithms1DataSet2.Process);

        }
        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e) // Only those selected in the checklist
        {
           
        }
        private void processDataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)// datagridview when a dynamic modification occurs
        {
            string str;
            int temp;
            string temp2;
            int[] random = new int[4];
            if (prcList.Count <= e.RowIndex)
            {
                Random rm = new Random();
                random[0] = rm.Next(1, 10);
                random[1] = rm.Next(0, 30);
                random[2] = rm.Next(0, 30);
                random[3] = rm.Next(1, 10);
                Proses p = new Proses(random[0], random[1], random[2], random[3]);
                for (int i = 0; i < 4; i++)
                {
                    if (i != e.ColumnIndex)
                    {
                        processDataGridView.Rows[e.RowIndex].Cells[i].Value = random[i].ToString();
                    }
                    else
                    {
                        if (i == 1)
                        {
                            temp2 = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                            temp = Convert.ToInt32(temp2);
                            p.ArriveTime = temp;
                        }
                        if (i == 2)
                        {
                            temp2 = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                            temp = Convert.ToInt32(temp2);
                            p.BurstTime = temp;
                        }
                        if (i == 3)
                        {
                            temp2 = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                            temp = Convert.ToInt32(temp2);
                            p.Priority = temp;
                        }
                        if (i == 0)
                        {
                            temp2 = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                            temp = Convert.ToInt32(temp2);
                            p.ProcessID = temp;
                        }

                    }
                }
                prcList.Add(p);
            }

            if (e.ColumnIndex == 0)
            {
                str = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                temp = Convert.ToInt32(str);
                if (temp > 100)
                {
                    temp = temp % 100;
                }
                prcList.ElementAt(e.RowIndex).ProcessID = temp;
                processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = temp.ToString();
            }
            else if (e.ColumnIndex == 1)
            {
                str = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                temp = Convert.ToInt32(str);
                if (temp > 100)
                {
                    temp = temp % 100;
                }
                prcList.ElementAt(e.RowIndex).ArriveTime = temp;
                processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = temp.ToString();
            }
            else if (e.ColumnIndex == 2)
            {
                str = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                temp = Convert.ToInt32(str);
                if (temp > 100)
                {
                    temp = temp % 100;
                }
                prcList.ElementAt(e.RowIndex).BurstTime = temp;
                processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = temp.ToString();
            }
            else if (e.ColumnIndex == 3)
            {
                str = processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                temp = Convert.ToInt32(str);
                if (temp > 100)
                {
                    temp = temp % 100;
                }
                prcList.ElementAt(e.RowIndex).Priority = temp;
                processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = temp.ToString();
            }
            processDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = System.Drawing.Color.Plum;
        }
        private void button2_Click(object sender, EventArgs e)
        {

            this.prcList.Clear();
            this.processDataGridView.Rows.Clear();
           


            processDataGridView.Rows.Clear();
            Random rm = new Random();
            int[] array = new int[10];
            int burst;
            int priorty;
            for (int i = 0; i < 5; i++)
            {
                array[i] = rm.Next(0, 30);
                burst = rm.Next(1, 30);
                priorty = rm.Next(1, 10);
                Proses p = new Proses(i + 1, array[i], burst, priorty);
                prcList.Add(p);
            }
            string[] row = { "", "", "", "" };
            foreach (Proses p in prcList)
            {
                row[0] = p.ProcessID.ToString();
                row[1] = p.ArriveTime.ToString();
                row[2] = p.BurstTime.ToString();
                row[3] = p.Priority.ToString();
                processDataGridView.Rows.Add(row);
            }
            for (int i = 0; i < prcList.Count; i++)
            {
                prcList.ElementAt(i).ProcessID = i + 1;
                processDataGridView.Rows[i].Cells[0].Value = (i + 1).ToString();
            }
            prcList.Sort(delegate (Proses x, Proses y)
            {
                return x.ArriveTime.CompareTo(y.ArriveTime);
            });
        }

        private void processBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.processBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.scheduling_algorithms1DataSet2);

        }

        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            for (int i = 0; i <= (checkedListBox1.Items.Count -1); i++)
            {
                if (checkedListBox1.GetItemChecked(i) == true)
                {
                    skedule[i] = true;
                    none = false;
                }
            }
            for (int i = 0; i <= (checkedListBox1.Items.Count -1); i++)
            {
                if (checkedListBox1.GetItemChecked(i) == false)
                {
                    skedule[i] = false;
                }
            }
        }

        private void Main_Form_Load(object sender, EventArgs e)
        {
            prcList = new List<Proses>();
            resList = new List<Resultaat>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckedListBox list;
            list = checkedListBox1;
            for (int i = 0; i < list.Items.Count; i++)
            {
                list.SetItemChecked(i, true);
                skedule[i] = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (prcList.Count == 0)
            {
                MessageBox.Show("Please enter data by clicking on generate button \n or" +
                    "enter them manually");
                return;
            }
            if ( skedule[1] == true || skedule[2] == true || skedule[0] == true)
            {
                if (skedule[0] == true)
                {
                    string value = "5";
                    value = Interaction.InputBox("Slicetime", "input");

                    sliceTime = Convert.ToInt32(value.ToString());
                }
                else
                {
                    sliceTime = 5;
                }
              
                algoFORM algfrm = new algoFORM(this);
                algfrm.Show();
            }
           
        
            
        }

       
    }
}

