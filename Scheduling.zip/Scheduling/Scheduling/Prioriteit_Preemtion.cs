﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scheduling
{
    class Prioriteit_Preemtion
    {
        public static List<Resultaat> Run(List<Proses> jobList)
        {
            int currentProcess = -1;
            int cpuTime = 0;
            int cpuDone = 0;
            int runTime = 0;
            int min;
            int SameValue;

            List<Resultaat> ResultaatList = new List<Resultaat>();
            List<Resultaat> readyQueue = new List<Resultaat>();
            do
            {
                if (jobList.Count != 0)
                {
                    if (jobList.ElementAt(0).ArriveTime == runTime) //Runtime 
                    {
                        SameValue = 1;
                        for (int i = 1; i < jobList.Count; i++, SameValue++)    //jobList
                        {
                            if (jobList.ElementAt(0).ArriveTime != jobList.ElementAt(i).ArriveTime) //
                                break;
                        }
                        for (int i = 0; i < SameValue; i++) //
                        {
                            readyQueue.Add(new Resultaat(jobList.ElementAt(0).ProcessID, 0, jobList.ElementAt(0).BurstTime, 0, jobList.ElementAt(0).Priority));
                            jobList.RemoveAt(0);
                        }
                    }
                }
                if (readyQueue.Count != 0)
                {
                    min = 0;
                    for (int i = 1; i < readyQueue.Count; i++) //readyQueue
                        if (readyQueue.ElementAt(i).Priority < readyQueue.ElementAt(min).Priority) 
                        {
                            min = i; 
                        }
                    if (currentProcess == -1) 
                    {
                        currentProcess = min;
                        cpuDone = readyQueue.ElementAt(currentProcess).burstTime;
                        cpuTime = 0;
                    }
                    else if (min != currentProcess) //
                    {

                        readyQueue[currentProcess].burstTime -= cpuTime; 
                        ResultaatList.Add(new Resultaat(readyQueue.ElementAt(currentProcess).processID, runTime - cpuTime,
                            cpuTime, readyQueue.ElementAt(currentProcess).waitingTime, readyQueue.ElementAt(currentProcess).Priority));

                        currentProcess = min;  
                        cpuDone = readyQueue.ElementAt(currentProcess).burstTime;
                        cpuTime = 0;
                    }
                    else
                    {
                        if (cpuTime == cpuDone)
                        {
                            ResultaatList.Add(new Resultaat(readyQueue.ElementAt(currentProcess).processID, runTime - readyQueue.ElementAt(currentProcess).burstTime,
                            readyQueue.ElementAt(currentProcess).burstTime, readyQueue.ElementAt(currentProcess).waitingTime, readyQueue.ElementAt(currentProcess).Priority));
                            readyQueue.RemoveAt(currentProcess); //Remove
                            currentProcess = -1;
                            continue;
                        }
                    }
                }

                cpuTime++;
                runTime++;
                for (int i = 0; i < readyQueue.Count; i++)
                {
                    if (i != currentProcess)
                        readyQueue.ElementAt(i).waitingTime++;
                }

            } while (jobList.Count != 0 || readyQueue.Count != 0 || currentProcess != -1);

            return ResultaatList;
        }
    }
}
