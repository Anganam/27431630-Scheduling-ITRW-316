﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scheduling
{
    public partial class algoFORM : Form
    {
        public List<Proses> oList, pView;
        public List<Resultaat> prioriteit, prioriteitPre;
        public List<Resultaat_Dubbel> roundRobin, roundRobin_dataView;
        public Form1 main = new Form1();
        int x = 0;
        int j = 0;
        SolidBrush[] prosesKleur;
        public int prex;
        double[] wagTyd = new double[6];
        Boolean[] skedule = new Boolean[6];

        public algoFORM()
        {
            InitializeComponent();
            oList = new List<Proses>();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

            if (main.skedule[0] == false)
            {
                return;
            }
            int startPosition = 10;
            double waitingTime = 0.0;
            int resultListPosition = 0;
            int i = 0;
            if (main.skedule[0] == true)
            {
                foreach (Resultaat_Dubbel r in roundRobin)
                {
                    i = r.processID;
                    e.Graphics.DrawString("p" + r.processID.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition);
                    e.Graphics.DrawRectangle(Pens.Black, startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                    e.Graphics.FillRectangle(prosesKleur[i - 1], startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                    e.Graphics.FillRectangle(Brushes.White, startPosition + (r.startP * 10) - x, resultListPosition + 20, 2, 30);
                    e.Graphics.DrawString(r.burstTime.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition + 60);
                    waitingTime += (double)r.waitingTime;
                }
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            if (main.skedule[1] == false)
            {
                return;
            }
            int startPosition = 10;
            double waitingTime = 0.0;
            Invalidate();
            int resultListPosition = 0;
            int i = 0;
            foreach (Resultaat r in prioriteit)
            {
                i = r.processID;
                e.Graphics.DrawString("p" + r.processID.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition);
                e.Graphics.DrawRectangle(Pens.Black, startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                e.Graphics.FillRectangle(prosesKleur[i - 1], startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                e.Graphics.FillRectangle(Brushes.White, startPosition + (r.startP * 10) - x, resultListPosition + 20, 2, 30);
                e.Graphics.DrawString(r.burstTime.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition + 60);
                e.Graphics.DrawString(r.waitingTime.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition + 80);
                waitingTime += (double)r.waitingTime;

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
            if (main.skedule[2] == false)
            {
                return;
            }
            int startPosition = 10;
            double waitingTime = 0.0;
            Invalidate();
            int resultListPosition = 0;
            int i = 0;
            foreach (Resultaat r in prioriteitPre)
            {
                i = r.processID;
                e.Graphics.DrawString("p" + r.processID.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition);
                e.Graphics.DrawRectangle(Pens.Black, startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                e.Graphics.FillRectangle(prosesKleur[i - 1], startPosition + (r.startP * 10) - x, resultListPosition + 20, r.burstTime * 10, 30);
                e.Graphics.FillRectangle(Brushes.White, startPosition + (r.startP * 10) - x, resultListPosition + 20, 2, 30);
                e.Graphics.DrawString(r.burstTime.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition + 60);
                e.Graphics.DrawString(r.waitingTime.ToString(), Font, Brushes.Black, startPosition + (r.startP * 10) - x, resultListPosition + 80);
                waitingTime += (double)r.waitingTime;
            }
        }

        private void priorityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.priorityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.scheduling_algorithms1DataSet1);

        }

        private void algoFORM_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'scheduling_algorithms1DataSet1.RoundRobin' table. You can move, or remove it, as needed.
            this.roundRobinTableAdapter.Fill(this.scheduling_algorithms1DataSet1.RoundRobin);
            // TODO: This line of code loads data into the 'scheduling_algorithms1DataSet1.Priority' table. You can move, or remove it, as needed.
            this.priorityTableAdapter.Fill(this.scheduling_algorithms1DataSet1.Priority);

        }
        public algoFORM(Form1 _form1)
        {
            InitializeComponent();
            oList = new List<Proses>();
            prioriteit = new List<Resultaat>();
            prioriteitPre = new List<Resultaat>();
            roundRobin = new List<Resultaat_Dubbel>();
            main = _form1;
            Random rand = new Random();
            prosesKleur = new SolidBrush[main.prcList.Count];

            for (int i = 0; i < main.prcList.Count; i++)
            {
                int R = rand.Next(10, 255);
                int G = rand.Next(10, 255);
                int B = rand.Next(10, 255);
                this.prosesKleur[i] = new SolidBrush(Color.FromArgb(R, G, B));
            }

            if (main.skedule[0] == true)//RR
            {
                int tyd = main.sliceTime;
                oList = new List<Proses>();
                double[] wT = new double[main.prcList.Count];
                for (int i = 0; i < main.prcList.Count; i++)
                {
                    Proses p = new Proses(main.prcList.ElementAt(i).ProcessID, main.prcList.ElementAt(i).ArriveTime, main.prcList.ElementAt(i).BurstTime, main.prcList.ElementAt(i).Priority);
                    oList.Add(p);
                }
                roundRobin = RoundRobin.Run(oList, tyd); //Calling the class's Run method // fcfs is a list of Result classes
                string[] row = new string[4];
                double busrtime = 0;
                for (int i = 0; i < roundRobin.Count; i++)
                {
                    if (wT[roundRobin.ElementAt(i).processID - 1] < roundRobin.ElementAt(i).waitingTime)
                    {
                        wT[roundRobin.ElementAt(i).processID - 1] = roundRobin.ElementAt(i).waitingTime;
                    }
                }
                j = 0;
                roundRobinDataGridView.Rows.Clear();
                double cpu_rr = 0;
                foreach (Resultaat_Dubbel r in roundRobin)
                {
                    row[0] = r.processID.ToString();
                    row[1] = r.burstTime.ToString();
                    row[2] = r.waitingTime.ToString();
                    row[3] = r.Priority.ToString();
                    busrtime += r.burstTime;
                    roundRobinDataGridView.Rows.Add(row);
                }

          
                cpu_rr = busrtime / (double)(roundRobin.ElementAt(0).startP + roundRobin.ElementAt(roundRobin.Count - 1).startP + roundRobin.ElementAt(roundRobin.Count - 1).burstTime);
                label3.Text = "CPU Utilization:" + (Math.Round(cpu_rr, 4) * 100) + "%";
                label2.Text = "Average wait time:" + (wagTyd[0] / main.prcList.Count).ToString();
                label1.Text = "Execution time:" + busrtime.ToString();
                prex = roundRobin[roundRobin.Count - 1].startP + roundRobin[roundRobin.Count - 1].burstTime;
                panel1.AutoScrollMinSize = new Size((prex * 11), panel1.Size.Height + 1);


            }

            if (main.skedule[1] == true)//Priorty
            {
                oList = new List<Proses>();
                for (int i = 0; i < main.prcList.Count; i++)
                {
                    Proses p = new Proses(main.prcList.ElementAt(i).ProcessID, main.prcList.ElementAt(i).ArriveTime, main.prcList.ElementAt(i).BurstTime, main.prcList.ElementAt(i).Priority);
                    oList.Add(p);
                }
                prioriteit = Prioriteit.Run(oList);
                dataGridView1.Rows.Clear();
                double busrtime = 0;
                double cpu_pri;
                string[] row = { "", "", "", "" };
                foreach (Resultaat r in prioriteit)
                {
                    row[0] = r.processID.ToString();
                    row[1] = r.burstTime.ToString();
                    row[2] = r.waitingTime.ToString();
                    row[3] = r.Priority.ToString();
                    busrtime += r.burstTime;
                    wagTyd[5] += r.waitingTime;
                    dataGridView1.Rows.Add(row);

                }
               
                cpu_pri = busrtime / (double)(prioriteit.ElementAt(0).startP + prioriteit.ElementAt(prioriteit.Count - 1).startP + prioriteit.ElementAt(prioriteit.Count - 1).burstTime);
                label4.Text = "CPU Utilization:" + (Math.Round(cpu_pri, 4) * 100) + "%";
                label5.Text = "Average wait time:" + (wagTyd[1] / main.prcList.Count).ToString();
                label6.Text = "Execution time:" + busrtime.ToString();
                prex = prioriteit[prioriteit.Count - 1].startP + prioriteit[prioriteit.Count - 1].burstTime;
                panel2.AutoScrollMinSize = new Size((prex * 11), panel2.Size.Height + 1);
            }

            if (main.skedule[2] == true)//Priorty preemtion
            {
                oList = new List<Proses>();
                double[] wT = new double[main.prcList.Count];
                for (int i = 0; i < main.prcList.Count; i++)
                {
                    Proses p = new Proses(main.prcList.ElementAt(i).ProcessID, main.prcList.ElementAt(i).ArriveTime, main.prcList.ElementAt(i).BurstTime, main.prcList.ElementAt(i).Priority);
                    oList.Add(p);
                }
                prioriteitPre = Prioriteit_Preemtion.Run(oList);


                for (int i = 0; i < prioriteitPre.Count; i++)
                {
                    if (wT[prioriteitPre.ElementAt(i).processID - 1] < prioriteitPre.ElementAt(i).waitingTime)
                    {
                        wT[prioriteitPre.ElementAt(i).processID - 1] = prioriteitPre.ElementAt(i).waitingTime;
                    }
                }
                dataGridView2.Rows.Clear();
                double busrtime = 0;
                double cpu_preem;
                string[] row = { "", "", "", "" };
                foreach (Resultaat r in prioriteitPre)
                {
                    row[0] = r.processID.ToString();
                    row[1] = r.burstTime.ToString();
                    row[2] = r.waitingTime.ToString();
                    row[3] = r.Priority.ToString();
                    busrtime += r.burstTime;
                    dataGridView2.Rows.Add(row);
                }


                cpu_preem = busrtime / (double)(prioriteitPre.ElementAt(0).startP + prioriteitPre.ElementAt(prioriteitPre.Count - 1).startP + prioriteitPre.ElementAt(prioriteitPre.Count - 1).burstTime);
                label7.Text = "CPU Utilization:" + (Math.Round(cpu_preem, 4) * 100) + "%";
                label8.Text = "Average wait time:" + (wagTyd[2] / main.prcList.Count).ToString();
                label9.Text = "Execution time:" + busrtime.ToString();
                prex = prioriteitPre[prioriteitPre.Count - 1].startP + prioriteitPre[prioriteitPre.Count - 1].burstTime;
                panel3.AutoScrollMinSize = new Size((prex * 11), panel3.Size.Height + 1);



            }
        }
    }
}
