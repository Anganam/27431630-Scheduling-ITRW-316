﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scheduling
{
    public class Resultaat_Dubbel
    {
        public int processID;
        public int startP;
        public int same;
        public int burstTime;
        public double waitingTime;
        public int Priority;

        public Resultaat_Dubbel(int processID, int startP, int burstTime, double waitingTime, int Priority, int same)
        {
            this.processID = processID;
            this.startP = startP;
            this.burstTime = burstTime;
            this.waitingTime = waitingTime;
            this.Priority = Priority;
            this.same = same;
        }
    }
}
