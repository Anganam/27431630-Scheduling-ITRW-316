﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scheduling
{
   public class Proses
    {
        public int ProcessID;
        public int ArriveTime;
        public int BurstTime;
        public int Priority;
        public int same = 0;

        public Proses(int ProcessID, int ArriveTime, int BurstTime, int Priority)
        {
            this.ProcessID = ProcessID;
            this.ArriveTime = ArriveTime;
            this.BurstTime = BurstTime;
            this.Priority = Priority;
        }

    }
}
